﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MediTrack.Services;

namespace MediTrack.Forms
{
    // Menu principal: muestra opciones segun el rol (RF01)
    public partial class FormMenuPrincipal : Form
    {
        public FormMenuPrincipal()
        {
            InitializeComponent();

            lblUsuario.Text = "Usuario: " + Sesion.UsuarioActual + "  (" + Sesion.RolActual + ")";

            // Todos los roles ven "Marcar asistencia" y "Justificaciones".
            // Las demas opciones se ocultan segun el rol.
            bool gestor = Sesion.EsGestor();
            btnPersonal.Visible = gestor;
            btnTurnos.Visible = gestor;
            btnJornadas.Visible = gestor;
            btnReportes.Visible = gestor;
            btnAreas.Visible = (Sesion.RolActual == Roles.Administrador);

            // Ajusta el alto de la ventana a los botones visibles
            flpOpciones.PerformLayout();
            this.ClientSize = new Size(this.ClientSize.Width, flpOpciones.Bottom + 25);
        }

        private void btnMarcar_Click(object sender, EventArgs e) { new FormMarcacion().ShowDialog(); }
        private void btnJustificaciones_Click(object sender, EventArgs e) { new FormJustificaciones().ShowDialog(); }
        private void btnPersonal_Click(object sender, EventArgs e) { new FormPersonal().ShowDialog(); }
        private void btnTurnos_Click(object sender, EventArgs e) { new FormTurnos().ShowDialog(); }
        private void btnJornadas_Click(object sender, EventArgs e) { new FormJornadas().ShowDialog(); }
        private void btnReportes_Click(object sender, EventArgs e) { new FormReportes().ShowDialog(); }
        private void btnAreas_Click(object sender, EventArgs e) { new FormAreas().ShowDialog(); }
        private void btnCerrarSesion_Click(object sender, EventArgs e) { this.Close(); }
    }
}
